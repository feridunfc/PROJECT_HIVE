# PROJECT_HIVE V15.0
Enterprise Multi-Agent Orchestration Framework.

## Quick Start
1. Activate venv: `source .venv/bin/activate` (Linux/Mac) or `.venv\Scripts\activate` (Win)
2. Run CLI: `python interfaces/cli/hive_cli.py "Build an API"`
3. Run API: `python interfaces/api/main.py`
